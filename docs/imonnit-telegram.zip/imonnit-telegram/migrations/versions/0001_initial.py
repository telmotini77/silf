"""Tablas iniciales

Revision ID: 0001
Revises:
"""
import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        "messages",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column("source", sa.String(20), nullable=False),
        sa.Column("provider_id", sa.String(512), nullable=False),
        sa.Column("message_id_header", sa.String(998)),
        sa.Column("subject", sa.Text()),
        sa.Column("sender", sa.Text()),
        sa.Column("sent_at", TS),
        sa.Column("raw", sa.LargeBinary(), nullable=False),
        sa.Column("raw_type", sa.String(10), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="recibido"),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("next_attempt_at", TS, nullable=False, server_default=sa.func.now()),
        sa.Column("last_error", sa.Text()),
        sa.Column("delivery", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", TS, nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", TS, nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("source", "provider_id", name="uq_messages_source_provider"),
    )
    op.create_index("ix_messages_pending", "messages", ["status", "next_attempt_at"])
    op.create_table(
        "oauth_tokens",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("provider", sa.String(20), nullable=False, unique=True),
        sa.Column("refresh_token_enc", sa.Text(), nullable=False),
        sa.Column("updated_at", TS, nullable=False, server_default=sa.func.now()),
    )
    op.create_table(
        "subscription_state",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("provider", sa.String(20), nullable=False, unique=True),
        sa.Column("external_id", sa.String(255)),
        sa.Column("cursor", sa.String(64)),
        sa.Column("expires_at", TS),
        sa.Column("updated_at", TS, nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("subscription_state")
    op.drop_table("oauth_tokens")
    op.drop_index("ix_messages_pending", table_name="messages")
    op.drop_table("messages")
