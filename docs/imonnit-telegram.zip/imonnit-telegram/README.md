# iMonnit → Telegram

Recibe alertas de iMonnit (por correo Gmail/Outlook o webhook directo), las guarda en
PostgreSQL y las reenvía a Telegram conservando su estructura.

## Arranque rápido

1. `cp .env.example .env` y genera secretos con `python scripts/gen_secrets.py`.
2. Crea el bot con **@BotFather**, añádelo al chat/grupo/canal (en canales, como admin),
   envía un mensaje y ejecuta `TELEGRAM_BOT_TOKEN=... python scripts/get_chat_id.py`.
3. Configura la fuente elegida (abajo).
4. `docker compose up -d --build` y comprueba `curl http://localhost:8000/health`.
5. Publica el puerto 8000 detrás de HTTPS (Caddy, Nginx o el proxy de Render/Railway).

## Gmail
1. Google Cloud: crea un proyecto, activa **Gmail API** y **Pub/Sub**.
2. Crea un tema Pub/Sub y dale el rol *Pub/Sub Publisher* a `gmail-api-push@system.gserviceaccount.com`.
3. Crea una suscripción **push** a `https://TU_DOMINIO/webhooks/gmail` con autenticación
   activada (cuenta de servicio + audiencia = esa misma URL).
4. Crea credenciales OAuth tipo *Desktop app* y ponlas en `.env`.
5. Con la base de datos levantada: `pip install -e ".[dev]"` y
   `DATABASE_URL=postgresql+asyncpg://app:<pass>@localhost:5432/imonnit python scripts/oauth_setup.py`
   (inicia sesión con el buzón dedicado; permiso solo `gmail.readonly`).

## Outlook / Microsoft 365
1. Entra ID → *Registro de aplicaciones* → nueva app → secreto de cliente.
2. Permiso de **aplicación** `Mail.Read` en Microsoft Graph + consentimiento de administrador.
3. Recomendado: limita la app al buzón dedicado con una *Application Access Policy*
   (`New-ApplicationAccessPolicy` en Exchange Online PowerShell).
4. Rellena las variables `MS_*`. La suscripción se crea y renueva sola.

## Webhook directo de iMonnit
Pon `MAIL_SOURCE=imonnit` y configura en iMonnit la URL
`https://TU_DOMINIO/webhooks/imonnit?token=<IMONNIT_WEBHOOK_SECRET>`
(o Basic Auth con ese secreto como contraseña).

## Administración
```
curl -H "Authorization: Bearer $ADMIN_TOKEN" https://TU_DOMINIO/admin/messages?status=fallido
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" https://TU_DOMINIO/admin/messages/42/retry
```

## Tests
`pip install -e ".[dev]" && pytest`
