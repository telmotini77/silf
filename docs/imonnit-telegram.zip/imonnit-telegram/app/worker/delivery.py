import asyncio
import json
import re
from collections.abc import Awaitable, Callable
from html import escape, unescape

from app.models import Message
from app.processing.formatter import build_equivalent, build_summary
from app.processing.imonnit_json import format_imonnit_json
from app.processing.parser import parse_eml
from app.processing.renderer import render_pdf
from app.processing.splitter import split_html, visible_text
from app.telegram.client import MAX_UPLOAD, TelegramClient, TelegramError

Mark = Callable[[str, int | None], Awaitable[None]]


def safe_filename(name: str) -> str:
    return re.sub(r"[^\w\-. ]+", "_", name).strip()[:80] or "correo"


async def send_html(tg: TelegramClient, html: str, reply_to: int | None = None) -> int:
    try:
        return await tg.send_message(html, reply_to)
    except TelegramError as e:
        if "parse entities" not in str(e).lower():
            raise
        # Último recurso: texto plano, para no perder la alerta
        return await tg.send_message(unescape(visible_text(html))[:4096], reply_to, html=False)


async def send_file(tg: TelegramClient, name: str, data: bytes, mime: str,
                    caption: str | None = None, reply_to: int | None = None) -> int:
    if len(data) > MAX_UPLOAD:
        return await send_html(tg, f"⚠️ Adjunto <b>{escape(name)}</b> omitido: supera 50 MB.", reply_to)
    return await tg.send_document(name, data, mime, caption, reply_to)


async def deliver(tg: TelegramClient, msg: Message, mode: str, tz: str, mark: Mark) -> None:
    """Cada paso tiene una clave; si ya se entregó en un intento previo, se salta."""
    done = dict(msg.delivery or {})

    async def step(key: str, action: Callable[[], Awaitable[int | None]]) -> int | None:
        if key in done:
            return done[key]
        result = await action()
        done[key] = result
        await mark(key, result)
        return result

    if msg.raw_type == "json":
        html = format_imonnit_json(json.loads(msg.raw))
        for i, chunk in enumerate(split_html(html)):
            await step(f"text:{i}", lambda c=chunk: send_html(tg, c))
        return

    parsed = parse_eml(msg.raw)
    anchor: int | None = None

    if mode in ("equivalent", "both"):
        for i, chunk in enumerate(split_html(build_equivalent(parsed, tz))):
            mid = await step(f"text:{i}", lambda c=chunk: send_html(tg, c))
            anchor = anchor or mid

    if mode in ("exact", "both"):
        if anchor is None:
            anchor = await step("summary", lambda: send_html(tg, split_html(build_summary(parsed, tz))[0]))
        name = safe_filename(parsed.subject)
        await step("eml", lambda: send_file(tg, f"{name}.eml", msg.raw, "message/rfc822",
                                            "📧 Correo original", anchor))

        async def _pdf() -> int | None:
            pdf = await asyncio.to_thread(render_pdf, parsed)
            if not pdf:
                return None
            return await send_file(tg, f"{name}.pdf", pdf, "application/pdf", "🖨️ Vista del correo", anchor)

        await step("pdf", _pdf)

    for i, att in enumerate(a for a in parsed.attachments if not a.inline):
        await step(f"att:{i}", lambda a=att: send_file(tg, a.filename, a.data, a.content_type,
                                                       reply_to=anchor))
