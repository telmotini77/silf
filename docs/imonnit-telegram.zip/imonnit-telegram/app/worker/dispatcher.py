import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.config import Settings
from app.models import Message
from app.telegram.client import TelegramClient, TelegramError
from app.worker.delivery import deliver

log = logging.getLogger(__name__)
PENDING = ("recibido", "reintentar")


async def _claim(sessionmaker: async_sessionmaker, limit: int = 5) -> list[int]:
    async with sessionmaker() as s:
        ids = (await s.execute(
            select(Message.id)
            .where(Message.status.in_(PENDING), Message.next_attempt_at <= datetime.now(timezone.utc))
            .order_by(Message.id).limit(limit)
            .with_for_update(skip_locked=True)  # varios workers sin duplicar envíos
        )).scalars().all()
        if ids:
            await s.execute(update(Message).where(Message.id.in_(ids)).values(status="enviando"))
        await s.commit()
        return list(ids)


async def _process(sessionmaker, tg: TelegramClient, settings: Settings, mid: int) -> None:
    async with sessionmaker() as s:
        msg = await s.get(Message, mid)

        async def mark(key: str, value: int | None) -> None:
            msg.delivery = {**(msg.delivery or {}), key: value}
            await s.commit()

        try:
            await deliver(tg, msg, settings.telegram_mode, settings.timezone, mark)
            msg.status, msg.last_error = "enviado", None
            log.info("Mensaje %s enviado a Telegram", mid)
        except Exception as e:
            msg.attempts += 1
            msg.last_error = f"{type(e).__name__}: {e}"[:2000]
            permanent = isinstance(e, TelegramError) and e.permanent
            if permanent or msg.attempts >= settings.max_attempts:
                msg.status = "fallido"
                log.error("Mensaje %s fallido definitivamente: %s", mid, msg.last_error)
            else:
                delay = min(30 * 2 ** (msg.attempts - 1), 3600)
                msg.status = "reintentar"
                msg.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=delay)
                log.warning("Mensaje %s reintento en %ss: %s", mid, delay, msg.last_error)
        await s.commit()


async def recover_stuck(sessionmaker: async_sessionmaker) -> None:
    """Si el proceso murió a mitad de un envío, devuelve el mensaje a la cola."""
    limit = datetime.now(timezone.utc) - timedelta(minutes=10)
    async with sessionmaker() as s:
        await s.execute(update(Message).where(Message.status == "enviando", Message.updated_at < limit)
                        .values(status="reintentar"))
        await s.commit()


async def run_dispatcher(sessionmaker, tg: TelegramClient, settings: Settings,
                         wake: asyncio.Event, stop: asyncio.Event) -> None:
    while not stop.is_set():
        try:
            ids = await _claim(sessionmaker)
            for mid in ids:
                await _process(sessionmaker, tg, settings, mid)
        except Exception:
            log.exception("Error en el dispatcher")
            ids = []
        if not ids:
            wake.clear()
            try:
                await asyncio.wait_for(wake.wait(), timeout=settings.worker_poll_seconds)
            except asyncio.TimeoutError:
                pass
