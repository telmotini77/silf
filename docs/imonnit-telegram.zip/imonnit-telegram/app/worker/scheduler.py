import asyncio
import logging
from datetime import datetime, timedelta, timezone

from app.sources.base import MailSource
from app.worker.dispatcher import recover_stuck

log = logging.getLogger(__name__)


async def _sleep(stop: asyncio.Event, seconds: float) -> None:
    try:
        await asyncio.wait_for(stop.wait(), timeout=seconds)
    except asyncio.TimeoutError:
        pass


async def run_scheduler(source: MailSource, sessionmaker, stop: asyncio.Event) -> None:
    # Esperar a que Uvicorn acepte peticiones: Graph valida la URL al crear la suscripción
    await _sleep(stop, 5)
    epoch = datetime.min.replace(tzinfo=timezone.utc)
    last_maintain = last_sync = epoch
    while not stop.is_set():
        now = datetime.now(timezone.utc)
        if now - last_maintain >= timedelta(hours=1):
            try:
                await source.maintain()
                last_maintain = now
            except Exception:
                log.exception("Error renovando watch/suscripción; reintento en 10 min")
                last_maintain = now - timedelta(minutes=50)
        if now - last_sync >= timedelta(minutes=5):
            try:
                await source.sync()
                await recover_stuck(sessionmaker)
            except Exception:
                log.exception("Error en la sincronización periódica")
            last_sync = now
        await _sleep(stop, 30)
