import asyncio
import json

import httpx

API = "https://api.telegram.org"
MAX_UPLOAD = 50 * 1024 * 1024


class TelegramError(Exception):
    def __init__(self, description: str, status: int | None = None, permanent: bool = False):
        super().__init__(description)
        self.status = status
        self.permanent = permanent


class TelegramClient:
    def __init__(self, token: str, chat_id: str, http: httpx.AsyncClient):
        self._token = token
        self._chat = chat_id
        self._http = http

    async def _call(self, method: str, data: dict, files: dict | None = None) -> dict:
        url = f"{API}/bot{self._token}/{method}"
        for _ in range(5):
            try:
                r = await self._http.post(url, data=data, files=files, timeout=120)
            except httpx.TransportError as e:
                # "from None" evita que la URL con el token acabe en los logs
                raise TelegramError(f"Error de red: {type(e).__name__}") from None
            try:
                body = r.json()
            except ValueError:
                raise TelegramError(f"Respuesta no JSON (HTTP {r.status_code})", r.status_code) from None
            if body.get("ok"):
                return body["result"]
            desc = body.get("description", "error desconocido")
            retry = (body.get("parameters") or {}).get("retry_after")
            if r.status_code == 429 and retry:
                await asyncio.sleep(min(int(retry), 120) + 1)
                continue
            permanent = r.status_code in (400, 401, 403, 404, 413) and "parse entities" not in desc.lower()
            raise TelegramError(desc, r.status_code, permanent)
        raise TelegramError("Límite de Telegram persistente (429)", 429)

    def _base(self, reply_to: int | None) -> dict:
        data = {"chat_id": self._chat}
        if reply_to:
            data["reply_parameters"] = json.dumps({"message_id": reply_to,
                                                   "allow_sending_without_reply": True})
        return data

    async def send_message(self, text: str, reply_to: int | None = None, html: bool = True) -> int:
        data = self._base(reply_to) | {"text": text,
                                       "link_preview_options": json.dumps({"is_disabled": True})}
        if html:
            data["parse_mode"] = "HTML"
        return (await self._call("sendMessage", data))["message_id"]

    async def send_document(self, filename: str, content: bytes, mime: str,
                            caption: str | None = None, reply_to: int | None = None) -> int:
        data = self._base(reply_to)
        if caption:
            data |= {"caption": caption[:1024], "parse_mode": "HTML"}
        files = {"document": (filename, content, mime)}
        return (await self._call("sendDocument", data, files))["message_id"]
