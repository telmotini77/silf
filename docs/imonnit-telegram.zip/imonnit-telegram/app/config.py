from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # General
    database_url: str = "postgresql+asyncpg://app:app@db:5432/imonnit"
    public_base_url: str  # https://tu-dominio.com (sin barra final)
    admin_token: str
    log_level: str = "INFO"
    timezone: str = "America/Guayaquil"

    # Fuente de correo: gmail | outlook | imonnit (solo webhook)
    mail_source: Literal["gmail", "outlook", "imonnit"] = "gmail"
    # Listas en formato JSON en el .env, p. ej. ["imonnit.com"]
    allowed_senders: list[str] = []
    subject_keywords: list[str] = []

    # Telegram
    telegram_bot_token: str
    telegram_chat_id: str
    telegram_mode: Literal["equivalent", "exact", "both"] = "both"

    # Cifrado de refresh tokens (Fernet)
    fernet_key: str | None = None

    # Gmail
    google_client_id: str | None = None
    google_client_secret: str | None = None
    gmail_pubsub_topic: str | None = None           # projects/<id>/topics/<nombre>
    gmail_pubsub_audience: str | None = None        # audiencia configurada en la suscripción push
    gmail_pubsub_service_account: str | None = None # cuenta de servicio que firma el push

    # Outlook / Microsoft Graph (permisos de aplicación)
    ms_tenant_id: str | None = None
    ms_client_id: str | None = None
    ms_client_secret: str | None = None
    ms_mailbox: str | None = None                   # alertas@tuempresa.com
    graph_client_state: str | None = None           # secreto aleatorio

    # Webhook directo de iMonnit (opcional, se activa si hay secreto)
    imonnit_webhook_secret: str | None = None

    # Worker
    max_attempts: int = 8
    worker_poll_seconds: float = 5.0

    def check_source(self) -> None:
        required = {
            "gmail": ["google_client_id", "google_client_secret", "gmail_pubsub_topic",
                      "gmail_pubsub_audience", "fernet_key"],
            "outlook": ["ms_tenant_id", "ms_client_id", "ms_client_secret",
                        "ms_mailbox", "graph_client_state"],
            "imonnit": ["imonnit_webhook_secret"],
        }[self.mail_source]
        missing = [k.upper() for k in required if not getattr(self, k)]
        if missing:
            raise RuntimeError(f"Faltan variables para {self.mail_source}: {', '.join(missing)}")


@lru_cache
def get_settings() -> Settings:
    return Settings()
