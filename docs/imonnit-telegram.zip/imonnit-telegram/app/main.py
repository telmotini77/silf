import asyncio
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI

from app.api import admin, health, webhooks
from app.config import get_settings
from app.db import SessionLocal, engine
from app.ingest import Ingestor
from app.logging_setup import setup_logging
from app.sources.base import MailSource, WebhookOnlySource
from app.sources.gmail import GmailSource
from app.sources.outlook import OutlookSource
from app.telegram.client import TelegramClient
from app.worker.dispatcher import run_dispatcher
from app.worker.scheduler import run_scheduler


def build_source(settings, http, ingestor) -> MailSource:
    cls = {"gmail": GmailSource, "outlook": OutlookSource, "imonnit": WebhookOnlySource}[settings.mail_source]
    return cls(settings, http, ingestor)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    setup_logging(settings.log_level)
    settings.check_source()

    http = httpx.AsyncClient(timeout=30)
    wake, stop = asyncio.Event(), asyncio.Event()
    ingestor = Ingestor(SessionLocal, settings, wake)
    source = build_source(settings, http, ingestor)
    telegram = TelegramClient(settings.telegram_bot_token, settings.telegram_chat_id, http)
    app.state.ingestor, app.state.source, app.state.wake = ingestor, source, wake

    tasks = [
        asyncio.create_task(run_dispatcher(SessionLocal, telegram, settings, wake, stop)),
        asyncio.create_task(run_scheduler(source, SessionLocal, stop)),
    ]
    yield
    stop.set()
    wake.set()
    await asyncio.gather(*tasks, return_exceptions=True)
    await http.aclose()
    await engine.dispose()


app = FastAPI(title="iMonnit → Telegram", lifespan=lifespan, docs_url=None, redoc_url=None)
app.include_router(health.router)
app.include_router(webhooks.router)
app.include_router(admin.router)
