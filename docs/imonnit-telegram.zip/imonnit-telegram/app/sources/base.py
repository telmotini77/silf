import logging
from datetime import datetime, timezone

import httpx
from sqlalchemy import select

from app.config import Settings
from app.ingest import Ingestor
from app.models import SubscriptionState

log = logging.getLogger(__name__)


class MailSource:
    name = "base"

    def __init__(self, settings: Settings, http: httpx.AsyncClient, ingestor: Ingestor):
        self.settings = settings
        self.http = http
        self.ingestor = ingestor

    async def maintain(self) -> None:
        """Crear/renovar watch o suscripción. Lo llama el scheduler cada hora."""

    async def sync(self) -> None:
        """Recuperar mensajes que no llegaron por push. Lo llama el scheduler cada 5 min."""

    async def _load_state(self) -> SubscriptionState | None:
        async with self.ingestor.sessionmaker() as s:
            res = await s.execute(select(SubscriptionState).where(SubscriptionState.provider == self.name))
            return res.scalar_one_or_none()

    async def _save_state(self, **fields) -> None:
        async with self.ingestor.sessionmaker() as s:
            res = await s.execute(select(SubscriptionState).where(SubscriptionState.provider == self.name))
            state = res.scalar_one_or_none() or SubscriptionState(provider=self.name)
            for k, v in fields.items():
                setattr(state, k, v)
            s.add(state)
            await s.commit()


class WebhookOnlySource(MailSource):
    """Modo iMonnit webhook: no hay buzón que vigilar."""
    name = "imonnit"


def parse_expiry(value: str | int | None) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, (int, float)) or str(value).isdigit():
        return datetime.fromtimestamp(int(value) / 1000, tz=timezone.utc)
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
