import asyncio
import base64
import logging
import time
from datetime import datetime, timedelta, timezone

import httpx
from sqlalchemy import select

from app.models import OAuthToken
from app.security import decrypt
from app.sources.base import MailSource, parse_expiry

log = logging.getLogger(__name__)
API = "https://gmail.googleapis.com/gmail/v1/users/me"
TOKEN_URL = "https://oauth2.googleapis.com/token"


class GmailSource(MailSource):
    name = "gmail"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._access: str | None = None
        self._access_exp = 0.0
        self._lock = asyncio.Lock()

    async def _token(self) -> str:
        if self._access and time.time() < self._access_exp - 60:
            return self._access
        async with self.ingestor.sessionmaker() as s:
            row = (await s.execute(select(OAuthToken).where(OAuthToken.provider == "google"))).scalar_one_or_none()
        if not row:
            raise RuntimeError("No hay refresh token de Google. Ejecuta scripts/oauth_setup.py")
        r = await self.http.post(TOKEN_URL, data={
            "client_id": self.settings.google_client_id,
            "client_secret": self.settings.google_client_secret,
            "refresh_token": decrypt(self.settings, row.refresh_token_enc),
            "grant_type": "refresh_token",
        })
        if r.status_code != 200:
            raise RuntimeError(f"Google rechazó el refresh token ({r.status_code}): repite oauth_setup.py")
        data = r.json()
        self._access, self._access_exp = data["access_token"], time.time() + data.get("expires_in", 3600)
        return self._access

    async def _api(self, method: str, path: str, **kw) -> dict:
        for attempt in range(2):
            token = await self._token()
            r = await self.http.request(method, API + path, headers={"Authorization": f"Bearer {token}"},
                                        timeout=30, **kw)
            if r.status_code == 401 and attempt == 0:
                self._access = None
                continue
            r.raise_for_status()
            return r.json()
        raise RuntimeError("inalcanzable")

    async def maintain(self) -> None:
        state = await self._load_state()
        # El watch dura 7 días; Google recomienda renovarlo a diario
        if state and state.expires_at and state.expires_at - datetime.now(timezone.utc) > timedelta(days=6):
            return
        data = await self._api("POST", "/watch", json={
            "topicName": self.settings.gmail_pubsub_topic, "labelIds": ["INBOX"]})
        fields = {"expires_at": parse_expiry(data.get("expiration"))}
        if not state or not state.cursor:
            fields["cursor"] = str(data["historyId"])
        await self._save_state(**fields)
        log.info("Gmail watch activo hasta %s", fields["expires_at"])

    async def sync(self) -> None:
        async with self._lock:
            state = await self._load_state()
            if not state or not state.cursor:
                log.info("Gmail aún sin cursor; se fijará al crear el watch")
                return
            ids: list[str] = []
            latest = state.cursor
            try:
                page = None
                while True:
                    params = {"startHistoryId": state.cursor, "historyTypes": "messageAdded",
                              "labelId": "INBOX"}
                    if page:
                        params["pageToken"] = page
                    data = await self._api("GET", "/history", params=params)
                    for h in data.get("history", []):
                        ids += [m["message"]["id"] for m in h.get("messagesAdded", [])]
                    latest = str(data.get("historyId", latest))
                    page = data.get("nextPageToken")
                    if not page:
                        break
            except httpx.HTTPStatusError as e:
                if e.response.status_code != 404:
                    raise
                log.warning("historyId caducado; resincronizando los últimos 2 días")
                data = await self._api("GET", "/messages", params={"q": "in:inbox newer_than:2d",
                                                                   "maxResults": 100})
                ids = [m["id"] for m in data.get("messages", [])]
                latest = str((await self._api("GET", "/profile"))["historyId"])

            for mid in dict.fromkeys(ids):
                if await self.ingestor.exists(self.name, mid):
                    continue
                try:
                    msg = await self._api("GET", f"/messages/{mid}", params={"format": "raw"})
                except httpx.HTTPStatusError as e:
                    if e.response.status_code == 404:
                        continue  # borrado antes de leerlo
                    raise
                raw = msg["raw"]
                await self.ingestor.ingest(self.name, mid,
                                           base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)), "eml")
            await self._save_state(cursor=latest)
