import hmac
import logging
import time
from datetime import datetime, timedelta, timezone

import httpx

from app.sources.base import MailSource, parse_expiry

log = logging.getLogger(__name__)
GRAPH = "https://graph.microsoft.com/v1.0"


class OutlookSource(MailSource):
    """Microsoft Graph con permisos de aplicación (Mail.Read) sobre un buzón dedicado."""
    name = "outlook"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._access: str | None = None
        self._access_exp = 0.0

    async def _token(self) -> str:
        if self._access and time.time() < self._access_exp - 60:
            return self._access
        s = self.settings
        r = await self.http.post(
            f"https://login.microsoftonline.com/{s.ms_tenant_id}/oauth2/v2.0/token",
            data={"client_id": s.ms_client_id, "client_secret": s.ms_client_secret,
                  "scope": "https://graph.microsoft.com/.default", "grant_type": "client_credentials"})
        r.raise_for_status()
        data = r.json()
        self._access, self._access_exp = data["access_token"], time.time() + data.get("expires_in", 3600)
        return self._access

    async def _request(self, method: str, url: str, **kw) -> httpx.Response:
        for attempt in range(2):
            r = await self.http.request(method, url, headers={"Authorization": f"Bearer {await self._token()}"},
                                        timeout=30, **kw)
            if r.status_code == 401 and attempt == 0:
                self._access = None
                continue
            r.raise_for_status()
            return r
        raise RuntimeError("inalcanzable")

    @property
    def _mailbox(self) -> str:
        return f"users/{self.settings.ms_mailbox}"

    def valid_client_state(self, value: str | None) -> bool:
        return bool(value) and hmac.compare_digest(value.encode(), self.settings.graph_client_state.encode())

    async def maintain(self) -> None:
        state = await self._load_state()
        now = datetime.now(timezone.utc)
        if state and state.external_id and state.expires_at and state.expires_at - now > timedelta(hours=24):
            return
        # Máximo para correo: 4230 min (<3 días). Pedimos 2 días y renovamos con 24 h de margen.
        expiry = (now + timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%S.0000000Z")
        if state and state.external_id:
            try:
                r = await self._request("PATCH", f"{GRAPH}/subscriptions/{state.external_id}",
                                        json={"expirationDateTime": expiry})
                await self._save_state(expires_at=parse_expiry(r.json()["expirationDateTime"]))
                log.info("Suscripción Graph renovada")
                return
            except httpx.HTTPStatusError as e:
                if e.response.status_code != 404:
                    raise
        r = await self._request("POST", f"{GRAPH}/subscriptions", json={
            "changeType": "created",
            "notificationUrl": f"{self.settings.public_base_url}/webhooks/graph",
            "resource": f"{self._mailbox}/mailFolders('Inbox')/messages",
            "expirationDateTime": expiry,
            "clientState": self.settings.graph_client_state,
        })
        data = r.json()
        await self._save_state(external_id=data["id"], expires_at=parse_expiry(data["expirationDateTime"]))
        log.info("Suscripción Graph creada: %s", data["id"])

    async def fetch_many(self, ids: list[str]) -> None:
        for mid in dict.fromkeys(ids):
            if await self.ingestor.exists(self.name, mid):
                continue
            try:
                r = await self._request("GET", f"{GRAPH}/{self._mailbox}/messages/{mid}/$value")
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    continue
                log.exception("Error descargando mensaje de Graph")
                continue
            await self.ingestor.ingest(self.name, mid, r.content, "eml")

    async def sync(self) -> None:
        r = await self._request("GET", f"{GRAPH}/{self._mailbox}/mailFolders/inbox/messages",
                                params={"$select": "id", "$top": "25", "$orderby": "receivedDateTime desc"})
        await self.fetch_many([m["id"] for m in r.json().get("value", [])])
