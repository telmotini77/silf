from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select

from app.db import SessionLocal
from app.models import Message
from app.security import require_admin

router = APIRouter(prefix="/admin", dependencies=[Depends(require_admin)])


@router.get("/messages")
async def list_messages(status: str | None = None, limit: int = Query(50, le=200)):
    stmt = select(Message.id, Message.source, Message.subject, Message.sender, Message.status,
                  Message.attempts, Message.last_error, Message.created_at).order_by(Message.id.desc()).limit(limit)
    if status:
        stmt = stmt.where(Message.status == status)
    async with SessionLocal() as s:
        rows = (await s.execute(stmt)).mappings().all()
    return [dict(r) for r in rows]


@router.post("/messages/{mid}/retry")
async def retry(mid: int, request: Request, reset: bool = False):
    """reset=true reenvía todo; si no, solo los pasos que faltaron."""
    async with SessionLocal() as s:
        msg = await s.get(Message, mid)
        if not msg:
            raise HTTPException(404)
        msg.status, msg.attempts = "reintentar", 0
        msg.next_attempt_at = datetime.now(timezone.utc)
        if reset:
            msg.delivery = {}
        await s.commit()
    request.app.state.wake.set()
    return {"ok": True}
