import base64
import hashlib
import json
import logging

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query, Request, Response
from fastapi.responses import PlainTextResponse
from fastapi.security.utils import get_authorization_scheme_param

from app.config import get_settings
from app.security import safe_equals, verify_pubsub
from app.sources.gmail import GmailSource
from app.sources.outlook import OutlookSource

log = logging.getLogger(__name__)
router = APIRouter(prefix="/webhooks")
MAX_BODY = 1024 * 1024


@router.post("/imonnit")
async def imonnit_webhook(request: Request, token: str = Query(default="")):
    secret = get_settings().imonnit_webhook_secret
    if not secret:
        raise HTTPException(404)
    # Acepta ?token=... o Basic Auth con la contraseña igual al secreto
    scheme, param = get_authorization_scheme_param(request.headers.get("authorization", ""))
    basic_pw = ""
    if scheme.lower() == "basic":
        try:
            basic_pw = base64.b64decode(param).decode().split(":", 1)[1]
        except Exception:
            pass
    if not (safe_equals(token, secret) or safe_equals(basic_pw, secret)):
        raise HTTPException(401)
    raw = await request.body()
    if len(raw) > MAX_BODY:
        raise HTTPException(413)
    try:
        json.loads(raw)
    except ValueError:
        raise HTTPException(400, "JSON inválido") from None
    await request.app.state.ingestor.ingest("imonnit", hashlib.sha256(raw).hexdigest(), raw, "json")
    return {"ok": True}


@router.post("/gmail")
async def gmail_push(request: Request, background: BackgroundTasks):
    source = request.app.state.source
    if not isinstance(source, GmailSource):
        raise HTTPException(404)
    await verify_pubsub(request, get_settings())
    # El contenido (historyId) no hace falta: sincronizamos desde el cursor guardado.
    background.add_task(source.sync)
    return Response(status_code=204)  # ACK para Pub/Sub


@router.post("/graph")
async def graph_notification(request: Request, background: BackgroundTasks,
                             validationToken: str | None = None):
    if validationToken is not None:  # validación al crear la suscripción
        return PlainTextResponse(validationToken)
    source = request.app.state.source
    if not isinstance(source, OutlookSource):
        raise HTTPException(404)
    payload = await request.json()
    ids = []
    for item in payload.get("value", []):
        if not source.valid_client_state(item.get("clientState")):
            log.warning("Notificación Graph con clientState inválido descartada")
            continue
        if rid := (item.get("resourceData") or {}).get("id"):
            ids.append(rid)
    if ids:
        background.add_task(source.fetch_many, ids)
    return Response(status_code=202)  # Graph exige respuesta en < 3 s
