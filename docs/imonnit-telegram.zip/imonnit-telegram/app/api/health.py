from fastapi import APIRouter
from sqlalchemy import text

from app.db import SessionLocal

router = APIRouter()


@router.get("/health")
async def health():
    async with SessionLocal() as s:
        await s.execute(text("SELECT 1"))
    return {"status": "ok"}
