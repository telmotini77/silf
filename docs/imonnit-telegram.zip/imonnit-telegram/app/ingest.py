import asyncio
import logging
from datetime import timezone
from email import policy
from email.parser import BytesHeaderParser
from email.utils import parsedate_to_datetime

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.config import Settings
from app.models import Message

log = logging.getLogger(__name__)


class Ingestor:
    """Guarda lo recibido y despierta al worker. Nunca envía a Telegram directamente."""

    def __init__(self, sessionmaker: async_sessionmaker, settings: Settings, wake: asyncio.Event):
        self.sessionmaker = sessionmaker
        self.settings = settings
        self.wake = wake

    def _accepted(self, sender: str, subject: str) -> bool:
        s, subj = sender.lower(), subject.lower()
        ok_sender = not self.settings.allowed_senders or any(a.lower() in s for a in self.settings.allowed_senders)
        ok_subject = not self.settings.subject_keywords or any(k.lower() in subj for k in self.settings.subject_keywords)
        return ok_sender and ok_subject

    async def exists(self, source: str, provider_id: str) -> bool:
        async with self.sessionmaker() as s:
            res = await s.execute(select(Message.id).where(Message.source == source,
                                                           Message.provider_id == provider_id))
            return res.first() is not None

    async def ingest(self, source: str, provider_id: str, raw: bytes, raw_type: str) -> bool:
        values = {"source": source, "provider_id": provider_id[:512], "raw": raw,
                  "raw_type": raw_type, "status": "recibido"}
        if raw_type == "eml":
            try:
                h = BytesHeaderParser(policy=policy.default).parsebytes(raw)
                subject, sender = str(h.get("subject") or ""), str(h.get("from") or "")
                values.update(subject=subject, sender=sender,
                              message_id_header=(str(h.get("message-id") or "")[:998] or None))
                if h.get("date"):
                    dt = parsedate_to_datetime(str(h["date"]))
                    values["sent_at"] = dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
                if not self._accepted(sender, subject):
                    values["status"] = "ignorado"
            except Exception:
                log.exception("No se pudieron leer las cabeceras de %s/%s", source, provider_id)

        stmt = (pg_insert(Message).values(**values)
                .on_conflict_do_nothing(constraint="uq_messages_source_provider")
                .returning(Message.id))
        async with self.sessionmaker() as s:
            new_id = (await s.execute(stmt)).scalar_one_or_none()
            await s.commit()

        if new_id is None:
            log.info("Duplicado ignorado: %s/%s", source, provider_id)
            return False
        log.info("Mensaje %s guardado (%s, estado=%s)", new_id, source, values["status"])
        if values["status"] == "recibido":
            self.wake.set()
        return True
