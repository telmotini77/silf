from datetime import datetime

from sqlalchemy import (BigInteger, DateTime, Index, Integer, LargeBinary, String, Text,
                        UniqueConstraint, func, text)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base

# Estados: recibido, enviando, reintentar, enviado, fallido, ignorado


class Message(Base):
    __tablename__ = "messages"
    __table_args__ = (
        UniqueConstraint("source", "provider_id", name="uq_messages_source_provider"),
        Index("ix_messages_pending", "status", "next_attempt_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    source: Mapped[str] = mapped_column(String(20))
    provider_id: Mapped[str] = mapped_column(String(512))
    message_id_header: Mapped[str | None] = mapped_column(String(998))
    subject: Mapped[str | None] = mapped_column(Text)
    sender: Mapped[str | None] = mapped_column(Text)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    raw: Mapped[bytes] = mapped_column(LargeBinary)
    raw_type: Mapped[str] = mapped_column(String(10))  # eml | json
    status: Mapped[str] = mapped_column(String(20), server_default="recibido")
    attempts: Mapped[int] = mapped_column(Integer, server_default="0")
    next_attempt_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    last_error: Mapped[str | None] = mapped_column(Text)
    # Pasos ya entregados a Telegram {"text:0": 123, "eml": 124, ...} -> idempotencia en reintentos
    delivery: Mapped[dict] = mapped_column(JSONB, server_default=text("'{}'::jsonb"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(),
                                                 onupdate=func.now())


class OAuthToken(Base):
    __tablename__ = "oauth_tokens"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider: Mapped[str] = mapped_column(String(20), unique=True)
    refresh_token_enc: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(),
                                                 onupdate=func.now())


class SubscriptionState(Base):
    __tablename__ = "subscription_state"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider: Mapped[str] = mapped_column(String(20), unique=True)
    external_id: Mapped[str | None] = mapped_column(String(255))  # ID de suscripción Graph / email Gmail
    cursor: Mapped[str | None] = mapped_column(String(64))        # historyId de Gmail
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(),
                                                 onupdate=func.now())
