from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.config import get_settings


class Base(DeclarativeBase):
    pass


engine = create_async_engine(get_settings().database_url, pool_pre_ping=True)
# expire_on_commit=False: el worker hace commits intermedios y sigue usando el objeto
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
