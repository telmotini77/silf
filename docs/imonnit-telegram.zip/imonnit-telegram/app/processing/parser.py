from dataclasses import dataclass, field
from datetime import datetime, timezone
from email import policy
from email.message import EmailMessage
from email.parser import BytesParser
from email.utils import parsedate_to_datetime


@dataclass
class Attachment:
    filename: str
    content_type: str
    data: bytes
    content_id: str | None = None
    inline: bool = False


@dataclass
class ParsedEmail:
    subject: str = ""
    sender: str = ""
    date: datetime | None = None
    message_id: str | None = None
    html: str | None = None
    text: str | None = None
    attachments: list[Attachment] = field(default_factory=list)


def _content(part: EmailMessage | None) -> str | None:
    if part is None:
        return None
    try:
        return part.get_content()
    except (LookupError, UnicodeDecodeError):  # charset desconocido o mal declarado
        payload = part.get_payload(decode=True) or b""
        return payload.decode(part.get_content_charset() or "utf-8", errors="replace")


def parse_eml(raw: bytes) -> ParsedEmail:
    msg: EmailMessage = BytesParser(policy=policy.default).parsebytes(raw)
    out = ParsedEmail(subject=str(msg.get("subject") or ""), sender=str(msg.get("from") or ""),
                      message_id=str(msg.get("message-id") or "") or None)
    if msg.get("date"):
        try:
            dt = parsedate_to_datetime(str(msg["date"]))
            out.date = dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            pass

    html_part = msg.get_body(preferencelist=("html",))
    text_part = msg.get_body(preferencelist=("plain",))
    out.html, out.text = _content(html_part), _content(text_part)

    for i, part in enumerate(msg.walk()):
        if part.is_multipart() or part is html_part or part is text_part:
            continue
        if part.get_content_maintype() == "message":
            continue
        disp = part.get_content_disposition()
        if part.get_content_maintype() == "text" and disp is None:
            continue
        cid = (part.get("content-id") or "").strip().strip("<>") or None
        data = part.get_payload(decode=True) or b""
        if not data:
            continue
        ext = (part.get_content_subtype() or "bin").split("+")[0]
        out.attachments.append(Attachment(
            filename=part.get_filename() or f"adjunto_{i}.{ext}",
            content_type=part.get_content_type(),
            data=data,
            content_id=cid,
            inline=disp != "attachment" and (cid is not None or disp == "inline"
                                             or part.get_content_maintype() == "image"),
        ))
    return out
