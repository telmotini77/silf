"""Formatea el payload del webhook de iMonnit. Los nombres de campo siguen el formato
habitual de iMonnit (gatewayMessage / sensorMessages); verifícalos con un payload real."""
from html import escape

SENSOR_FIELDS = [
    ("sensorName", "Sensor"), ("sensorID", "ID"), ("dataValue", "Valor"),
    ("plotValues", "Lectura"), ("plotLabels", "Unidad"), ("state", "Estado"),
    ("messageDate", "Fecha"), ("batteryLevel", "Batería"), ("signalStrength", "Señal"),
]


def _e(v) -> str:
    return escape(str(v), quote=False)


def format_imonnit_json(payload: dict) -> str:
    lines = ["🔔 <b>Alerta iMonnit</b>"]
    sensors = payload.get("sensorMessages") or []
    for s in sensors:
        lines.append("")
        lines += [f"<b>{label}:</b> {_e(s[key])}" for key, label in SENSOR_FIELDS
                  if s.get(key) not in (None, "")]
    gw = payload.get("gatewayMessage") or {}
    if gw.get("gatewayName") or gw.get("gatewayID"):
        lines.append(f"\n<i>Gateway:</i> {_e(gw.get('gatewayName') or gw.get('gatewayID'))}")
    if not sensors:  # formato desconocido: volcado legible
        for k, v in payload.items():
            if isinstance(v, dict):
                lines += [f"<b>{_e(k)}.{_e(k2)}:</b> {_e(v2)}" for k2, v2 in v.items()
                          if not isinstance(v2, (dict, list))]
            elif not isinstance(v, list):
                lines.append(f"<b>{_e(k)}:</b> {_e(v)}")
    return "\n".join(lines)
