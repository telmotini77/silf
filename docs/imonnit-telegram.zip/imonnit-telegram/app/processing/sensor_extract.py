"""Extrae pares clave/valor del sensor. Es la única parte específica de iMonnit:
ajústala con un correo real si las etiquetas no coinciden."""
import re

from bs4 import BeautifulSoup

KEYWORDS = ("sensor", "valor", "value", "reading", "lectura", "temperatura", "temperature",
            "humedad", "humidity", "estado", "status", "alerta", "alert", "notificación",
            "notification", "batería", "battery", "señal", "signal", "fecha", "date", "hora",
            "time", "gateway", "dispositivo", "device", "red", "network", "umbral", "threshold")
PAIR_RE = re.compile(r"^\s*([^:\n]{2,60}):\s*(.+?)\s*$")


def extract_pairs(html: str | None, text: str | None, limit: int = 15) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    source_text = text or ""
    if html:
        soup = BeautifulSoup(html, "lxml")
        for tr in soup.find_all("tr"):
            if tr.find("table"):
                continue  # fila de maquetación
            cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"], recursive=False)]
            cells = [c for c in cells if c]
            if len(cells) == 2 and len(cells[0]) <= 60:
                pairs.append((cells[0].rstrip(":").strip(), cells[1]))
        source_text = soup.get_text("\n")
    for line in source_text.splitlines():
        m = PAIR_RE.match(line)
        if m:
            pairs.append((m.group(1).strip(), m.group(2)))

    seen, out = set(), []
    for key, value in pairs:
        norm = (key.lower(), value)
        if norm in seen or not any(w in key.lower() for w in KEYWORDS):
            continue
        seen.add(norm)
        out.append((key, value))
    return out[:limit]
