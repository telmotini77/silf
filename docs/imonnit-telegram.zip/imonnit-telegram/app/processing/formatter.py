"""Convierte el HTML de un correo al subconjunto HTML que acepta Telegram."""
import re
from html import escape
from zoneinfo import ZoneInfo

import nh3
from bs4 import BeautifulSoup, Comment, NavigableString, Tag

from app.processing.parser import ParsedEmail
from app.processing.sensor_extract import extract_pairs

TELEGRAM_TAGS = {"b", "i", "u", "s", "a", "code", "pre", "blockquote"}
INLINE = {"b": "b", "strong": "b", "i": "i", "em": "i", "u": "u", "ins": "u",
          "s": "s", "strike": "s", "del": "s", "code": "code", "tt": "code"}
HEADINGS = {"h1", "h2", "h3", "h4", "h5", "h6"}
SKIP = {"script", "style", "head", "title", "meta", "link", "noscript", "template", "svg", "button", "form"}
BLOCK = {"p", "div", "section", "article", "header", "footer", "main", "center", "ul", "ol",
         "tr", "td", "th", "tbody", "thead", "tfoot", "dl", "dt", "dd", "address", "figure"}
SEPARATOR = "━━━━━━━━━━━━"


def _hidden(tag: Tag) -> bool:
    style = (tag.get("style") or "").replace(" ", "").lower()
    return "display:none" in style or "visibility:hidden" in style or tag.has_attr("hidden")


def _children(node: Tag) -> str:
    return "".join(_render(c) for c in node.children)


def _render_table(table: Tag) -> str:
    rows = []
    for tr in table.find_all("tr"):
        if tr.find_parent("table") is not table:
            continue
        cells = [_children(td).strip() for td in tr.find_all(["td", "th"], recursive=False)]
        cells = [c for c in cells if c]
        if not cells:
            continue
        if len(cells) == 2 and "\n" not in cells[0] and len(re.sub(r"<[^>]+>", "", cells[0])) <= 60:
            label = cells[0].rstrip(":").strip()
            rows.append(f"<b>{label}:</b> {cells[1]}")       # tabla clave/valor
        elif len(cells) == 1 or any("\n" in c for c in cells):
            rows.append("\n".join(cells))                     # tabla de maquetación
        else:
            rows.append(" | ".join(cells))                    # tabla de datos
    return "\n".join(rows)


def _render(node) -> str:
    if isinstance(node, Comment):
        return ""
    if isinstance(node, NavigableString):
        return escape(re.sub(r"\s+", " ", str(node)), quote=False)
    if not isinstance(node, Tag):
        return ""
    name = node.name.lower()
    if name in SKIP or _hidden(node):
        return ""
    if name == "br":
        return "\n"
    if name == "hr":
        return f"\n{SEPARATOR}\n"
    if name == "img":
        return ""
    if name in HEADINGS:
        inner = _children(node).strip()
        return f"\n<b>{inner}</b>\n" if inner else ""
    if name in INLINE:
        inner = _children(node)
        tag = INLINE[name]
        return f"<{tag}>{inner}</{tag}>" if inner.strip() else inner
    if name == "a":
        inner = _children(node)
        href = (node.get("href") or "").strip()
        if href.startswith(("http://", "https://", "mailto:")):
            return f'<a href="{escape(href, quote=True)}">{inner.strip() or escape(href)}</a>'
        return inner
    if name == "pre":
        return f"\n<pre>{escape(node.get_text(), quote=False)}</pre>\n"
    if name == "blockquote":
        inner = _children(node).strip()
        return f"\n<blockquote>{inner}</blockquote>\n" if inner else ""
    if name == "li":
        return f"\n• {_children(node).strip()}"
    if name == "table":
        return f"\n{_render_table(node)}\n"
    if name in BLOCK:
        return f"\n{_children(node)}\n"
    return _children(node)


def html_to_telegram(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")
    root = soup.body or soup
    out = _render(root)
    out = re.sub(r"[ \t]+\n", "\n", out)
    out = re.sub(r"\n[ \t]+", "\n", out)
    out = re.sub(r"\n{3,}", "\n\n", out).strip()
    # Segunda barrera: solo etiquetas/atributos que Telegram acepta
    return nh3.clean(out, tags=TELEGRAM_TAGS, attributes={"a": {"href"}},
                     url_schemes={"http", "https", "mailto"}, link_rel=None, strip_comments=True)


def _header(parsed: ParsedEmail, tz: str) -> str:
    lines = [f"🔔 <b>{escape(parsed.subject or '(sin asunto)', quote=False)}</b>"]
    if parsed.sender:
        lines.append(f"<i>De:</i> {escape(parsed.sender, quote=False)}")
    if parsed.date:
        local = parsed.date.astimezone(ZoneInfo(tz))
        lines.append(f"<i>Fecha:</i> {local.strftime('%d/%m/%Y %H:%M:%S')}")
    return "\n".join(lines)


def build_equivalent(parsed: ParsedEmail, tz: str) -> str:
    """Opción 1: el correo completo con formato equivalente."""
    if parsed.html:
        body = html_to_telegram(parsed.html)
    else:
        body = escape(parsed.text or "", quote=False).strip()
    return f"{_header(parsed, tz)}\n{SEPARATOR}\n{body or '<i>(correo sin contenido)</i>'}"


def build_summary(parsed: ParsedEmail, tz: str) -> str:
    """Opción 2: resumen corto; el correo original va como .eml/PDF en respuesta."""
    pairs = extract_pairs(parsed.html, parsed.text)
    if pairs:
        body = "\n".join(f"<b>{escape(k, quote=False)}:</b> {escape(v, quote=False)}" for k, v in pairs)
    else:
        text = parsed.text or (BeautifulSoup(parsed.html, "lxml").get_text(" ") if parsed.html else "")
        text = re.sub(r"\s+", " ", text).strip()
        body = escape(text[:700] + ("…" if len(text) > 700 else ""), quote=False)
    return f"{_header(parsed, tz)}\n{SEPARATOR}\n{body}\n\n📎 <i>Correo original adjunto abajo.</i>"
