"""Opción 2 (copia exacta): renderiza el HTML del correo a PDF."""
import logging
from html import escape

from app.processing.parser import ParsedEmail

log = logging.getLogger(__name__)


def render_pdf(parsed: ParsedEmail) -> bytes | None:
    try:
        from weasyprint import HTML
    except Exception:
        log.warning("WeasyPrint no disponible; se omite el PDF")
        return None

    cid_map = {a.content_id: a for a in parsed.attachments if a.content_id}

    def fetcher(url: str, *args, **kwargs) -> dict:
        # Solo imágenes incrustadas (cid:). Nada remoto: evita rastreo y SSRF.
        if url.startswith("cid:") and (att := cid_map.get(url[4:])):
            return {"string": att.data, "mime_type": att.content_type}
        raise ValueError(f"Recurso bloqueado: {url[:80]}")

    header = (
        '<div style="font-family:sans-serif;font-size:12px;border-bottom:1px solid #ccc;'
        'margin-bottom:12px;padding-bottom:8px">'
        f"<b>Asunto:</b> {escape(parsed.subject)}<br><b>De:</b> {escape(parsed.sender)}<br>"
        f"<b>Fecha:</b> {parsed.date.isoformat() if parsed.date else '-'}</div>"
    )
    body = parsed.html or f"<pre>{escape(parsed.text or '')}</pre>"
    try:
        return HTML(string=header + body, url_fetcher=fetcher).write_pdf()
    except Exception:
        log.exception("No se pudo renderizar el PDF")
        return None
