"""Divide HTML de Telegram en bloques <= límite sin romper etiquetas ni entidades."""
import re

TOKEN_RE = re.compile(r"(<[^>]+>)")
NAME_RE = re.compile(r"</?\s*([a-zA-Z0-9-]+)")
TAG_RE = re.compile(r"<[^>]+>")


def visible_text(html: str) -> str:
    return TAG_RE.sub("", html)


def _safe_cut(text: str, n: int) -> int:
    if n >= len(text):
        return len(text)
    idx = text.rfind("\n", 0, n)
    if idx < n // 2:
        idx = text.rfind(" ", 0, n)
    if idx < n // 2:
        idx = n
    amp = text.rfind("&", 0, idx)
    if amp != -1 and ";" not in text[amp:idx] and idx - amp < 10:
        idx = amp  # no partir &amp; &lt; ...
    return max(idx, 1)


def split_html(html: str, limit: int = 4096) -> list[str]:
    chunks: list[str] = []
    stack: list[tuple[str, str]] = []
    cur = ""

    def closing() -> str:
        return "".join(f"</{n}>" for n, _ in reversed(stack))

    def reopen() -> str:
        return "".join(t for _, t in stack)

    def flush() -> None:
        nonlocal cur
        body = (cur + closing()).strip()
        if visible_text(body).strip():
            chunks.append(body)
        cur = reopen()

    for tok in TOKEN_RE.split(html):
        if not tok:
            continue
        if tok.startswith("<"):
            m = NAME_RE.match(tok)
            if not m:
                continue
            name, is_close = m.group(1).lower(), tok.startswith("</")
            extra = 0 if is_close else len(name) + 3
            if len(cur) + len(tok) + len(closing()) + extra > limit:
                flush()
            cur += tok
            if is_close:
                for i in range(len(stack) - 1, -1, -1):
                    if stack[i][0] == name:
                        del stack[i]
                        break
            else:
                stack.append((name, tok))
            continue
        text = tok
        while text:
            room = limit - len(cur) - len(closing())
            if len(text) <= room:
                cur += text
                break
            if room < 50 and cur != reopen():
                flush()
                continue
            cut = _safe_cut(text, max(room, 1))
            cur += text[:cut]
            text = text[cut:]
            flush()
    flush()
    return chunks
