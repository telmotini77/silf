import asyncio
import hmac

from cryptography.fernet import Fernet
from fastapi import Header, HTTPException, Request

from app.config import Settings, get_settings


def encrypt(settings: Settings, value: str) -> str:
    return Fernet(settings.fernet_key.encode()).encrypt(value.encode()).decode()


def decrypt(settings: Settings, value: str) -> str:
    return Fernet(settings.fernet_key.encode()).decrypt(value.encode()).decode()


def safe_equals(a: str | None, b: str | None) -> bool:
    return bool(a) and bool(b) and hmac.compare_digest(a.encode(), b.encode())


async def require_admin(authorization: str = Header(default="")) -> None:
    token = authorization.removeprefix("Bearer ").strip()
    if not safe_equals(token, get_settings().admin_token):
        raise HTTPException(status_code=401, detail="No autorizado")


async def verify_pubsub(request: Request, settings: Settings) -> None:
    """Verifica el JWT OIDC que Google Pub/Sub adjunta a cada push."""
    from google.auth.transport import requests as google_requests
    from google.oauth2 import id_token

    auth = request.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Falta token")
    token = auth[7:]

    def _verify() -> dict:
        return id_token.verify_oauth2_token(token, google_requests.Request(),
                                            audience=settings.gmail_pubsub_audience)

    try:
        claims = await asyncio.to_thread(_verify)
    except Exception:
        raise HTTPException(status_code=401, detail="Token inválido") from None
    expected = settings.gmail_pubsub_service_account
    if expected and (claims.get("email") != expected or not claims.get("email_verified")):
        raise HTTPException(status_code=401, detail="Emisor no permitido")
