"""Autoriza el buzón Gmail una sola vez y guarda el refresh token cifrado.

Ejecutar en tu máquina (necesita navegador):
  pip install -e ".[dev]"
  DATABASE_URL=postgresql+asyncpg://app:app@localhost:5432/imonnit python scripts/oauth_setup.py
"""
import asyncio

from google_auth_oauthlib.flow import InstalledAppFlow
from sqlalchemy import select

from app.config import get_settings
from app.db import SessionLocal
from app.models import OAuthToken
from app.security import encrypt

SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]


async def main() -> None:
    s = get_settings()
    flow = InstalledAppFlow.from_client_config({"installed": {
        "client_id": s.google_client_id, "client_secret": s.google_client_secret,
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "redirect_uris": ["http://localhost"]}}, SCOPES)
    creds = flow.run_local_server(port=0, access_type="offline", prompt="consent")
    if not creds.refresh_token:
        raise SystemExit("Google no devolvió refresh token; revoca el acceso y repite.")
    async with SessionLocal() as db:
        row = (await db.execute(select(OAuthToken).where(OAuthToken.provider == "google"))).scalar_one_or_none()
        row = row or OAuthToken(provider="google")
        row.refresh_token_enc = encrypt(s, creds.refresh_token)
        db.add(row)
        await db.commit()
    print("Refresh token guardado (cifrado). Ya puedes arrancar el servicio.")


if __name__ == "__main__":
    asyncio.run(main())
