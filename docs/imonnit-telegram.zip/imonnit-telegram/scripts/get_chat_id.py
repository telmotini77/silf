"""Escribe algo al bot (o añádelo al grupo/canal y publica un mensaje) y ejecuta:
  TELEGRAM_BOT_TOKEN=xxx python scripts/get_chat_id.py
"""
import os

import httpx

token = os.environ["TELEGRAM_BOT_TOKEN"]
r = httpx.get(f"https://api.telegram.org/bot{token}/getUpdates", timeout=30).json()
seen = set()
for upd in r.get("result", []):
    msg = upd.get("message") or upd.get("channel_post") or upd.get("my_chat_member") or {}
    chat = msg.get("chat")
    if chat and chat["id"] not in seen:
        seen.add(chat["id"])
        print(f'{chat["id"]}\t{chat.get("type")}\t{chat.get("title") or chat.get("username") or ""}')
if not seen:
    print("Sin actualizaciones: envía un mensaje al bot y vuelve a intentarlo.")
