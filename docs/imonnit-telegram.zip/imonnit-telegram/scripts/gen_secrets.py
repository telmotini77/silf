"""Genera los secretos del .env."""
import secrets

from cryptography.fernet import Fernet

print(f"FERNET_KEY={Fernet.generate_key().decode()}")
print(f"ADMIN_TOKEN={secrets.token_urlsafe(32)}")
print(f"GRAPH_CLIENT_STATE={secrets.token_urlsafe(32)}")
print(f"IMONNIT_WEBHOOK_SECRET={secrets.token_urlsafe(32)}")
