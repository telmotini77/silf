from email.message import EmailMessage

import pytest

SAMPLE_HTML = """<html><head><style>.x{color:red}</style></head><body>
<div style="display:none">Texto oculto de vista previa</div>
<table><tr><td><img src="cid:logo123" alt="logo"></td></tr>
<tr><td>
  <h2>Alerta de temperatura</h2>
  <p>El sensor ha superado el <strong>umbral</strong> configurado.</p>
  <table>
    <tr><td>Sensor:</td><td>Cámara Fría 1</td></tr>
    <tr><td>Lectura:</td><td>9.4 °C</td></tr>
    <tr><td>Estado:</td><td>Alerta &lt;crítica&gt;</td></tr>
    <tr><td>Fecha:</td><td>23/09/2026 08:15</td></tr>
  </table>
  <ul><li>Revisar puerta</li><li>Revisar compresor</li></ul>
  <p><a href="https://www.imonnit.com/">Ver en iMonnit</a> <a href="javascript:alert(1)">malo</a></p>
</td></tr></table></body></html>"""


@pytest.fixture
def sample_eml() -> bytes:
    msg = EmailMessage()
    msg["Subject"] = "Alerta: Cámara Fría 1 - Temperatura"
    msg["From"] = "iMonnit <notifications@imonnit.com>"
    msg["To"] = "alertas@example.com"
    msg["Date"] = "Wed, 23 Sep 2026 13:15:00 +0000"
    msg["Message-ID"] = "<abc123@imonnit.com>"
    msg.set_content("Sensor: Cámara Fría 1\nLectura: 9.4 °C\nEstado: Alerta")
    msg.add_alternative(SAMPLE_HTML, subtype="html")
    msg.get_payload()[1].add_related(b"\x89PNG fake", maintype="image", subtype="png", cid="<logo123>")
    msg.add_attachment(b"a,b\n1,2\n", maintype="text", subtype="csv", filename="lecturas.csv")
    return msg.as_bytes()
