from app.processing.parser import parse_eml


def test_parse_basic(sample_eml):
    p = parse_eml(sample_eml)
    assert p.subject.startswith("Alerta")
    assert "imonnit.com" in p.sender
    assert p.date is not None and p.date.tzinfo is not None
    assert "Cámara Fría 1" in p.html
    assert "Lectura" in p.text


def test_attachments(sample_eml):
    p = parse_eml(sample_eml)
    by_name = {a.filename: a for a in p.attachments}
    assert "lecturas.csv" in by_name and not by_name["lecturas.csv"].inline
    logo = [a for a in p.attachments if a.content_id == "logo123"]
    assert logo and logo[0].inline
