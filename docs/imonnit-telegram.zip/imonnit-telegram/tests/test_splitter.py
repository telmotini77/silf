import re

from app.processing.splitter import split_html


def _balanced(html: str) -> bool:
    stack = []
    for m in re.finditer(r"<(/?)([a-z]+)[^>]*>", html):
        if m.group(1):
            if not stack or stack.pop() != m.group(2):
                return False
        else:
            stack.append(m.group(2))
    return not stack


def test_short_untouched():
    assert split_html("<b>hola</b>") == ["<b>hola</b>"]


def test_long_split_respects_limit_and_tags():
    html = "<b>" + ("palabra &amp; otra " * 800) + "</b>\n" + "<i>fin</i>"
    chunks = split_html(html, limit=1000)
    assert len(chunks) > 1
    for c in chunks:
        assert len(c) <= 1000
        assert _balanced(c)
        assert not re.search(r"&[a-z]*$", c.replace("</b>", "").replace("</i>", ""))
