from app.processing.imonnit_json import format_imonnit_json


def test_sensor_messages():
    out = format_imonnit_json({"gatewayMessage": {"gatewayName": "GW-1"},
                               "sensorMessages": [{"sensorName": "Cámara <1>", "dataValue": "9.4",
                                                   "plotLabels": "°C", "batteryLevel": 88}]})
    assert "<b>Sensor:</b> Cámara &lt;1&gt;" in out
    assert "<b>Batería:</b> 88" in out and "GW-1" in out
