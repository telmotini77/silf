from app.processing.formatter import build_equivalent, build_summary, html_to_telegram
from app.processing.parser import parse_eml
from tests.conftest import SAMPLE_HTML


def test_structure_preserved():
    out = html_to_telegram(SAMPLE_HTML)
    assert "<b>Alerta de temperatura</b>" in out
    assert "<b>umbral</b>" in out
    assert "<b>Sensor:</b> Cámara Fría 1" in out
    assert "• Revisar puerta" in out
    assert '<a href="https://www.imonnit.com/">Ver en iMonnit</a>' in out


def test_sanitized():
    out = html_to_telegram(SAMPLE_HTML)
    assert "javascript" not in out
    assert "Texto oculto" not in out
    assert "color:red" not in out
    assert "&lt;crítica&gt;" in out  # escapado, no etiqueta


def test_builders(sample_eml):
    p = parse_eml(sample_eml)
    eq = build_equivalent(p, "America/Guayaquil")
    assert eq.startswith("🔔 <b>Alerta")
    assert "23/09/2026 08:15:00" in eq  # 13:15 UTC -> 08:15 Guayaquil
    summary = build_summary(p, "America/Guayaquil")
    assert "<b>Lectura:</b> 9.4 °C" in summary
